// SPDX-License-Identifier: GPL-3.0-only
/*
 *  Nori Client - Minecraft Launcher
 *  Copyright (C) 2023 Rachel Powers <508861+Ryex@users.noreply.github.com>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, version 3.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 */

#include "net/ApiDownload.h"

#include <utility>
#include "net/ApiHeaderProxy.h"

namespace Net {

Download::Ptr ApiDownload::makeCached(QUrl url, MetaEntryPtr entry, Download::Options options)
{
    auto dl = Download::makeCached(std::move(url), std::move(entry), options);
    dl->addHeaderProxy(std::make_unique<ApiHeaderProxy>());
    return dl;
}

std::pair<Download::Ptr, QByteArray*> ApiDownload::makeByteArray(QUrl url, Download::Options options)
{
    auto [dl, response] = Download::makeByteArray(std::move(url), options);
    dl->addHeaderProxy(std::make_unique<ApiHeaderProxy>());
    return { dl, response };
}

Download::Ptr ApiDownload::makeFile(QUrl url, QString path, Download::Options options, ModrinthDownloadMeta meta)
{
    auto dl = Download::makeFile(std::move(url), std::move(path), options);
    dl->addHeaderProxy(std::make_unique<ApiHeaderProxy>(std::move(meta)));
    return dl;
}

}  // namespace Net
