#pragma once
#include <QObject>

#include "minecraft/auth/AuthStep.h"
#include "net/NetJob.h"
#include "net/Upload.h"

class XboxUserStep : public AuthStep {
    Q_OBJECT

   public:
    explicit XboxUserStep(AccountData* data);
    virtual ~XboxUserStep() noexcept = default;

    void perform() override;

    QString describe() override;

   private slots:
    void onRequestDone(QByteArray* response);

   private:
    Net::Upload::Ptr m_request;
    NetJob::Ptr m_task;
};
