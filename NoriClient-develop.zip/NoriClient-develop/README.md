<p align="center">
<picture>
  <source media="(prefers-color-scheme: dark)" srcset="/program_info/org.noriclient.NoriClient.logo-darkmode.svg">
  <source media="(prefers-color-scheme: light)" srcset="/program_info/org.noriclient.NoriClient.logo.svg">
  <img alt="Nori Client" src="/program_info/org.noriclient.NoriClient.logo.svg" width="40%">
</picture>
</p>

<p align="center">
  Nori Client is a custom launcher for Minecraft that allows you to easily manage multiple installations of Minecraft at once.<br />
  <br />This is a <b>fork</b> of the MultiMC Launcher and is <b>not</b> endorsed by it.
</p>

## Installation

<a href="https://repology.org/project/noriclient/versions">
    <img src="https://repology.org/badge/vertical-allrepos/noriclient.svg" alt="Packaging status" align="right">
</a>

- All downloads and instructions for Nori Client can be found on our [Website](https://noriclient.org/download).
- Last build status can be found in the [GitHub Actions](https://github.com/NoriClient/NoriClient/actions) tab (this also includes the pull requests status).

### Development Builds

Please understand that these builds are not intended for most users. There may be bugs, and other instabilities. You have been warned.

There are development builds available through:

- [GitHub Actions](https://github.com/NoriClient/NoriClient/actions) (includes builds from pull requests opened by contributors)
- [nightly.link](https://noriclient.org/nightly) (this will always point only to the latest version of develop)

These have debug information in the binaries, so their file sizes are relatively larger.

Prebuilt Development builds are provided for **Linux**, **Windows** and **macOS**.

On Linux, we also offer our own [Flatpak nightly repository](https://github.com/NoriClient/flatpak). Most software centers are able to install it by opening [this link](https://flatpak.noriclient.org/noriclient-nightly.flatpakref).

## Community & Support

Feel free to create a GitHub issue if you find a bug or want to suggest a new feature. We have multiple community spaces where other community members can help you:

- **Our Discord server:**

[![Nori Client Discord server](https://discordapp.com/api/guilds/1031648380885147709/widget.png?style=banner3)](https://noriclient.org/discord)

- **Our Matrix space:**

[![Nori Client Space](https://img.shields.io/matrix/noriclient:matrix.org?style=for-the-badge&label=Matrix%20Space&logo=matrix&color=purple)](https://noriclient.org/matrix)

- **Our Subreddit:**

[![r/NoriClient](https://img.shields.io/reddit/subreddit-subscribers/noriclient?style=for-the-badge&logo=reddit)](https://noriclient.org/reddit)

## Translations

The translation effort for Nori Client is hosted on [Weblate](https://hosted.weblate.org/projects/noriclient/launcher/) and information about translating Nori Client is available at <https://github.com/NoriClient/Translations>.

## Building

If you want to build Nori Client yourself, check the [build instructions](https://noriclient.org/wiki/development/build-instructions).

## Sponsors & Partners

We thank all the wonderful backers over at Open Collective! Support Nori Client by [becoming a backer](https://opencollective.com/noriclient).

[![OpenCollective Backers](https://opencollective.com/noriclient/backers.svg?width=890&limit=1000)](https://opencollective.com/noriclient#backers)

Thanks to JetBrains for providing us a few licenses for all their products, as part of their [Open Source program](https://www.jetbrains.com/opensource/).

<a href="https://jb.gg/OpenSource">
<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://www.jetbrains.com/company/brand/img/logo_jb_dos_4.svg">
  <source media="(prefers-color-scheme: light)" srcset="https://resources.jetbrains.com/storage/products/company/brand/logos/jetbrains.svg">
  <img alt="JetBrains logo" src="https://resources.jetbrains.com/storage/products/company/brand/logos/jetbrains.svg" width="40%">
</picture>
</a>

Thanks to Weblate for hosting our translation efforts.

<a href="https://hosted.weblate.org/engage/noriclient/">
<img src="https://hosted.weblate.org/widgets/noriclient/-/open-graph.png" alt="Translation status" width="300" />
</a>

Thanks to Netlify for providing us their excellent web services, as part of their [Open Source program](https://www.netlify.com/open-source/).

<a href="https://www.netlify.com"> <img src="https://www.netlify.com/v3/img/components/netlify-color-accent.svg" alt="Deploys by Netlify" /> </a>

Thanks to the awesome people over at [MacStadium](https://www.macstadium.com/), for providing M1-Macs for development purposes!

<a href="https://www.macstadium.com"><img src="https://uploads-ssl.webflow.com/5ac3c046c82724970fc60918/5c019d917bba312af7553b49_MacStadium-developerlogo.png" alt="Powered by MacStadium" width="300"></a>

## Forking/Redistributing/Custom builds policy

You are free to fork, redistribute and provide custom builds as long as you follow the terms of the [license](LICENSE) (this is a legal responsibility), and if you made code changes rather than just packaging a custom build, please do the following as a basic courtesy:

- Make it clear that your fork is not Nori Client and is not endorsed by or affiliated with the Nori Client project (<https://noriclient.org>).
- Go through [CMakeLists.txt](CMakeLists.txt) and change Nori Client's API keys to your own or set them to empty strings (`""`) to disable them (this way the program will still compile but the functionality requiring those keys will be disabled).

If you have any questions or want any clarification on the above conditions please make an issue and ask us.

If you are just building Nori Client for your distribution, please make sure to set the `Launcher_BUILD_PLATFORM` to a slug representing your distribution. Examples are `archlinux`, `fedora` and `nixpkgs`.

Note that if you build this software without removing the provided API keys in [CMakeLists.txt](CMakeLists.txt) you are accepting the following terms and conditions:

- [Microsoft Identity Platform Terms of Use](https://docs.microsoft.com/en-us/legal/microsoft-identity-platform/terms-of-use)
- [CurseForge 3rd Party API Terms and Conditions](https://support.curseforge.com/en/support/solutions/articles/9000207405-curse-forge-3rd-party-api-terms-and-conditions)

If you do not agree with these terms and conditions, then remove the associated API keys from the [CMakeLists.txt](CMakeLists.txt) file by setting them to an empty string (`""`).

## License [![https://github.com/NoriClient/NoriClient/blob/develop/LICENSE](https://img.shields.io/github/license/NoriClient/NoriClient?label=License&logo=gnu&color=C4282D)](LICENSE)

All launcher code is available under the GPL-3.0-only license.

The logo and related assets are under the CC BY-SA 4.0 license.
